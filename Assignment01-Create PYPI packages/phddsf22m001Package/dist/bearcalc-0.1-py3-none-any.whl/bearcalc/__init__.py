#__init__.py file

def add(a, b):
    return a+b

def subtract(a, b):
    return a-b
    
def multiply(a, b):
    return a*b

def devide(a, b):
    return a/b
    